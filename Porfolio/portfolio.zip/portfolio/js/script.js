
    $(document).ready(function(){
        $(".fa-bars").click(function(){

            $(".navbar").slideToggle(500);
        });
        $("#slide").cycle("fade");

      
    })









