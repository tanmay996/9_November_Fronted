
  



    $(document).ready(function(){
        $(".fa-bars").click(function(){
            $(".navbar").css({"visibility": "visible"});
            $(".navbar").slideToggle(500);
        });
        $("#slide").cycle("fade");
    })








